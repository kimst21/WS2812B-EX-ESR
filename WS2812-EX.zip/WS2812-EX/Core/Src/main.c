/* Includes ------------------------------------------------------------------*/
#include "main.h"   // 메인 헤더 파일 포함
#include "dma.h"    // DMA 관련 헤더 파일 포함
#include "tim.h"    // 타이머 관련 헤더 파일 포함
#include "gpio.h"   // GPIO 관련 헤더 파일 포함

/* Private includes ----------------------------------------------------------*/
#include "stm32f4xx_hal.h"  // HAL 라이브러리 포함 (STM32F4 시리즈용)

/* Private typedef -----------------------------------------------------------*/
/* 네오픽셀 RGB LED의 색상 데이터를 저장하는 구조체 (24비트) */
typedef union
{
  struct
  {
    uint8_t b;  // 파란색 (Blue) 값
    uint8_t r;  // 빨간색 (Red) 값
    uint8_t g;  // 초록색 (Green) 값
  } color;
  uint32_t data; // 전체 24비트 색상 데이터
} PixelRGB_t;

/* 네오픽셀 RGBW LED의 색상 데이터를 저장하는 구조체 (32비트) */
typedef union
{
  struct
  {
    uint8_t w;  // 흰색 (White) 값
    uint8_t b;  // 파란색 (Blue) 값
    uint8_t r;  // 빨간색 (Red) 값
    uint8_t g;  // 초록색 (Green) 값
  } color;
  uint32_t data; // 전체 32비트 색상 데이터
} PixelRGBW_t;

/* Private define ------------------------------------------------------------*/
#define NEOPIXEL_ZERO 34 // 0비트에 해당하는 PWM 펄스 폭 (타이머 값)
#define NEOPIXEL_ONE  67 // 1비트에 해당하는 PWM 펄스 폭 (타이머 값)

#define NUM_PIXELS    30  // 제어할 네오픽셀 LED의 개수
#define DMA_BUFF_SIZE (NUM_PIXELS * 32) + 1  // DMA 버퍼 크기 (LED 30개, 각 LED당 32비트 전송 + 종료용 데이터 1개)

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void); // 시스템 클럭 설정 함수 프로토타입 선언

/* PWM 전송 완료 시 호출되는 콜백 함수 */
void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim4)
{
  HAL_TIM_PWM_Stop_DMA(htim4, TIM_CHANNEL_1); // DMA를 이용한 PWM 전송 중지
}

/**
  * @brief  메인 프로그램 시작점
  */
int main(void)
{
  /* LED 및 DMA 버퍼 초기화 */
  PixelRGB_t pixel[NUM_PIXELS] = {0};  // LED 색상 데이터를 저장하는 배열
  uint32_t dmaBuffer[DMA_BUFF_SIZE] = {0};  // DMA를 통해 PWM을 전송할 버퍼
  uint32_t *pBuff;  // DMA 버퍼 포인터
  int i, j, k;  // 루프 인덱스 변수
  uint16_t stepSize = 4;  // 색상 변화 속도 (4씩 증가)

  /* STM32 HAL 및 시스템 클럭 초기화 */
  HAL_Init();
  SystemClock_Config();

  /* 주변 장치 초기화 */
  MX_GPIO_Init();  // GPIO 초기화
  MX_DMA_Init();   // DMA 초기화
  MX_TIM4_Init();  // TIM4 타이머를 PWM 모드로 초기화

  /* LED 색상 변화 루프 */
  k = 0;
  while (1)
  {
    /* LED 색상 이동 (시프트) */
    for (i = (NUM_PIXELS - 1); i > 0; i--)
    {
      pixel[i].data = pixel[i - 1].data; // 이전 LED 색상을 다음 LED로 이동
    }

    /* 색상 변화 로직 (RGB 그라데이션 효과) */
    if (k < 255)
    {
      pixel[0].color.g = 254 - k; // 녹색 감소 [254, 0]
      pixel[0].color.r = k + 1;   // 빨강 증가 [1, 255]
      pixel[0].color.b = 0;        // 파랑 유지 (0)
    }
    else if (k < 510)
    {
      pixel[0].color.g = 0;
      pixel[0].color.r = 509 - k; // 빨강 감소 [254, 0]
      pixel[0].color.b = k - 254; // 파랑 증가 [1, 255]
    }
    else if (k < 765)
    {
      pixel[0].color.g = k - 509; // 녹색 증가 [1, 255]
      pixel[0].color.r = 0;
      pixel[0].color.b = 764 - k; // 파랑 감소 [254, 0]
    }
    k = (k + stepSize) % 765; // 색상 변경을 위한 인덱스 증가 및 순환

    /* 밝기 조정 (4단계 감소) */
    pixel[0].color.g >>= 2;
    pixel[0].color.r >>= 2;
    pixel[0].color.b >>= 2;

    /* DMA 버퍼로 LED 데이터 변환 */
    pBuff = dmaBuffer;
    for (i = 0; i < NUM_PIXELS; i++)
    {
       for (j = 23; j >= 0; j--) // RGB 24비트 데이터 변환 (MSB 우선)
       {
         if ((pixel[i].data >> j) & 0x01) // 현재 비트가 1인지 확인
         {
           *pBuff = NEOPIXEL_ONE; // 1이면 긴 PWM 신호
         }
         else
         {
           *pBuff = NEOPIXEL_ZERO; // 0이면 짧은 PWM 신호
         }
         pBuff++; // 버퍼 위치 이동
       }
    }
    dmaBuffer[DMA_BUFF_SIZE - 1] = 0; // 마지막 DMA 전송 데이터는 0으로 설정

    /* PWM을 이용한 DMA 전송 시작 */
    HAL_TIM_PWM_Start_DMA(&htim4, TIM_CHANNEL_1, dmaBuffer, DMA_BUFF_SIZE);

    HAL_Delay(20); // 20ms 대기 후 반복
  }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
